Lien vers le téléchargement du driver :
    https://www.silabs.com/developers/usb-to-uart-bridge-vcp-drivers

