#include <Arduino.h>
#include <WiFi.h>
#include <CAN.h>

// commenter ou décommenter pour avoir les tags détectés sur la console
//#define DEBUG_CONSOLE
// robot A : "IA" ou robot B : "IB"
#define ROBOT "IA"

const char *ssid = "TP-Link_64E0";
const char *password = "54631267";
// const char *ssid = "SFR_FF20";
// const char *password = "litwyctogriteset4jer";

const uint16_t port = 8090;
const char *host = "192.168.0.105";
// const char *host = "192.168.1.22";

char donnee;
String line;

WiFiClient client;
unsigned long previousMillis = 0;
unsigned long clientAliveMillis = 0;
unsigned long interval = 1000;

int etat = 0;
uint16_t id;
uint8_t length, remoteRequest, message[8];

void initCanBus()
{
  // start the CAN bus at 1000 kbps
  while (!CAN.begin(1000E3))
  {
    Serial.println("Starting CAN failed!");
  }
}

void initWiFi()
{
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password);
  Serial.print("Connecting to WiFi ..");
  while (WiFi.status() != WL_CONNECTED)
  {
    Serial.print('.');
    delay(500);
  }
  Serial.print("WiFi connected with IP: ");
  Serial.println(WiFi.localIP());
}

void setup()
{
  Serial.begin(115200);

  initWiFi();
  initCanBus();
}

void loop()
{
  unsigned long currentMillis = millis();
  // if WiFi is down, try reconnecting every CHECK_WIFI_TIME seconds
  if (WiFi.status() != WL_CONNECTED)
  {
    if (currentMillis - previousMillis >= interval)
    {
      Serial.println("Reconnecting to WiFi...");
      WiFi.disconnect();
      WiFi.reconnect();
      previousMillis = currentMillis;
    }
  }
  else
  {

    if (!client.connected())
    {
      if (!client.connect(host, port))
      {

        Serial.println("Connection to host failed");

        delay(1000);
      }
      else
      {
        client.print("IA");
        Serial.println("Connected to server successful!");
        clientAliveMillis = currentMillis;
      }
    }

    while (client.available())
    {
      bool newMessage = false;
      uint8_t count;
      int data = client.read();
      switch (etat)
      {
      case 0:
        if (data == '*')
          etat = 1;
        break;
      case 1:
        id = data;
        etat = 2;
        break;
      case 2:
        id += (data << 8);
        etat = 3;
        break;
      case 3:
        length = data;
        if (length > 8)
          etat = 0;
        else
          etat = 4;
        break;
      case 4:
        remoteRequest = data;
        if (remoteRequest != 0)
        {
          newMessage = true;
        }
        else
        {
          count = 0;
          etat = 5;
        }
        break;
      case 5:
        message[count++] = data;
        if (count >= length)
        {
          newMessage = true;
        }
        break;
      }
      if (newMessage)
      {
        newMessage = false;
        etat = 0;
#ifdef DEBUG_CONSOLE
        int tag = message[0];
        int x = int16_t(message[1] + 256 * message[2]);
        int y = int16_t(message[3] + 256 * message[4]);
        int a = int16_t(message[5] + 256 * message[6]);
        Serial.printf("%03X %d %d %d %d\n", id, tag, x, y, a);
#endif
        if (remoteRequest != 0)
        {
          CAN.beginPacket(id, length, true);
        }
        else
        {
          CAN.beginPacket(id);
          for (int i = 0; i < length; i++)
            CAN.write(message[i]);
        }
        CAN.endPacket();
      }
    }
    if (currentMillis - clientAliveMillis >= interval)
    {
      client.print("!"); // message d'un caractère pour se signaler
      clientAliveMillis = currentMillis;
    }
        // try to parse packet
    int packetSize = CAN.parsePacket();
    if (packetSize) {
      uint8_t message[20] = {'*'};
      message[1] = CAN.packetId() & 0xFF;
      message[2] = (CAN.packetId() >> 8) & 0xFF;    
      message[3] = CAN.packetDlc();
      message[4] = CAN.packetRtr();
      int i=5;
      while (CAN.available()) message[i++] = CAN.read();
      if (client.connected()) client.write(message, i);
    }
  }
}
